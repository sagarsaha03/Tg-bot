from client import Bot

if __name__ == "__main__":
    print("🚀 Starting Movie Search Bot...")
    Bot().run()
