import aiohttp
import asyncio
from bs4 import BeautifulSoup

async def inspect_website():
    url = "https://skymovieshd.mba/search.php?search=Van+Helsing&cat=All"
    
    async with aiohttp.ClientSession() as session:
        async with session.get(url) as response:
            content = await response.text()
            
            # Save complete HTML
            with open("website.html", "w", encoding="utf-8") as f:
                f.write(content)
            print("✅ HTML saved to website.html")
            
            soup = BeautifulSoup(content, 'html.parser')
            
            # Find ALL elements to understand structure
            print("\n🔍 ALL ELEMENTS ANALYSIS:")
            
            # Check all div classes
            all_divs = soup.find_all('div')
            div_classes = set()
            for div in all_divs[:50]:  # First 50 divs
                if div.get('class'):
                    div_classes.add(' '.join(div.get('class')))
            
            print(f"📦 Div classes found: {list(div_classes)[:10]}")
            
            # Check all elements with movie-like content
            print("\n🎬 MOVIE-LIKE ELEMENTS:")
            for element in soup.find_all(['div', 'article', 'section', 'li'])[:20]:
                text = element.get_text().strip()
                if text and len(text) > 20 and any(keyword in text.lower() for keyword in ['van', 'helsing', 'movie', 'download']):
                    print(f"📌 Text: {text[:50]}...")
                    print(f"   Class: {element.get('class')}")
                    print(f"   Tag: {element.name}")
                    print("   ---")
            
            # Find all links with text
            print("\n🔗 ALL LINKS WITH TEXT:")
            links = soup.find_all('a', href=True)
            for link in links[:15]:
                text = link.get_text().strip()
                href = link.get('href', '')
                if text and len(text) > 10:
                    print(f"📌 {text} -> {href}")

asyncio.run(inspect_website())
