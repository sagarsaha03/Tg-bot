import asyncio
import sys
import os

# Add current directory to path
sys.path.append(os.getcwd())

from scraper.skymovies import SkyMoviesScraper

async def test_scraper():
    print("🔍 Testing SkyMoviesHD Scraper...")
    
    scraper = SkyMoviesScraper()
    
    # Test different queries
    test_queries = ["van helsing", "avengers", "kgf", "test"]
    
    for query in test_queries:
        print(f"\n🎬 Testing: '{query}'")
        movies = await scraper.search_movies(query)
        
        if movies:
            print(f"✅ Found {len(movies)} movies:")
            for i, movie in enumerate(movies, 1):
                print(f"   {i}. {movie['title']}")
                print(f"      URL: {movie['url']}")
                if movie.get('poster'):
                    print(f"      Poster: {movie['poster'][:50]}...")
        else:
            print("❌ No movies found")
    
    print("\n🎯 Test completed!")

if __name__ == "__main__":
    asyncio.run(test_scraper())
