import aiohttp
import asyncio
from bs4 import BeautifulSoup

async def test_movie_page():
    # Test with actual movie URL
    movie_url = "https://skymovieshd.mba/movie/Chhath-(2025)-Bhojpuri-1080p-HDRip-x264-AAC-HC-ESub-Full-Bhojpuri-Movie-[2.4GB].html"
    
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
    }
    
    async with aiohttp.ClientSession() as session:
        async with session.get(movie_url, headers=headers) as response:
            content = await response.text()
            
            # Save HTML for inspection
            with open("movie_page.html", "w", encoding="utf-8") as f:
                f.write(content)
            print("✅ Movie page HTML saved to movie_page.html")
            
            soup = BeautifulSoup(content, 'html.parser')
            
            # Find ALL links
            all_links = soup.find_all('a', href=True)
            print(f"🔗 Found {len(all_links)} total links")
            
            # Show links that might be download links
            print("\n📥 Possible download links:")
            for link in all_links:
                href = link.get('href', '')
                text = link.get_text().strip()
                
                if any(keyword in href.lower() for keyword in [
                    'download', 'terabox', 'gdrive', 'mega', 'mediafire', 
                    'gofile', 'streamtape', 'upload', 'file'
                ]):
                    print(f"✅ {text} -> {href}")
            
            # Also check buttons
            print("\n🔄 Checking buttons:")
            buttons = soup.find_all('button')
            for btn in buttons:
                text = btn.get_text().strip()
                if text and any(word in text.lower() for word in ['download', 'get', 'link']):
                    print(f"🎯 Button: {text}")

asyncio.run(test_movie_page())
