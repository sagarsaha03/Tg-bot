from pyrogram import Client

api_id = 27932904  # Your API ID
api_hash = "bd1969abffc09157194e1c8d24fb97df"  # Your API Hash

with Client("my_account", api_id, api_hash) as app:
    print("Session string:", app.export_session_string())
